# Welcome to Mistral based Bot! 🚀🤖

Hi there, 👋 We're excited to have you on board. This is a powerful bot designed to help you ask queries related to your data/knowledge.

## Useful Links 🔗

- **Data:** This is the data which has been used as a knowledge base. [Knowledge Base](https://docs.chainlit.io) 📚
- **Model:** This is the model used from HuggingFace (<https://huggingface.co/TheBloke/CapybaraHermes-2.5-Mistral-7B-GGUF>)

Happy chatting! 💻
